Gruppenname: roommaze
Matrikelnummer: 01526044 und 01635862
GPU: Nvidia GTX 1070 8GB